from django import forms
from .models import Demande


class DemandeForm(forms.ModelForm):

    class Meta:

        model = Demande

        fields = [
            'titre',
            'description',
            'nom_demandeur',
            'email',
            'emplacement',
            'categorie',
            'statut',
        ]

        widgets = {

            'titre': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Titre de la demande'
            }),

            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Description du problème'
            }),

            'nom_demandeur': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nom du demandeur'
            }),

            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Adresse email'
            }),

            'emplacement': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Emplacement'
            }),

            'categorie': forms.Select(attrs={
                'class': 'form-select'
            }),

            'statut': forms.Select(attrs={
                'class': 'form-select'
            }),
        }