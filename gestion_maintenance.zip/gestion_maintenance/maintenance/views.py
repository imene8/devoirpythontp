from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages

from .models import Demande, Categorie
from .forms import DemandeForm


# Page d'accueil
def accueil(request):

    total_demandes = Demande.objects.count()

    total_categories = Categorie.objects.count()

    demandes_attente = Demande.objects.filter(
        statut='En attente'
    ).count()

    demandes_resolues = Demande.objects.filter(
        statut='Résolue'
    ).count()

    context = {
        'total_demandes': total_demandes,
        'total_categories': total_categories,
        'demandes_attente': demandes_attente,
        'demandes_resolues': demandes_resolues,
    }

    return render(request, 'maintenance/accueil.html', context)


# Liste des demandes
def liste_demandes(request):

    demandes = Demande.objects.all().order_by('-date_creation')

    return render(
        request,
        'maintenance/demande_list.html',
        {'demandes': demandes}
    )


# Détails d'une demande
def detail_demande(request, id):

    demande = get_object_or_404(Demande, id=id)

    return render(
        request,
        'maintenance/demande_detail.html',
        {
            'demande': demande,
            'statut_choices': Demande.STATUT_CHOICES
        }
    )

# Ajouter une demande
def ajouter_demande(request):

    if request.method == 'POST':

        form = DemandeForm(request.POST)

        if form.is_valid():

            form.save()

            messages.success(
                request,
                'Demande ajoutée avec succès !'
            )

            return redirect('liste_demandes')

    else:

        form = DemandeForm()

    return render(
        request,
        'maintenance/demande_form.html',
        {
            'form': form,
            'titre_page': 'Ajouter une demande'
        }
    )


# Modifier une demande
def modifier_demande(request, id):

    demande = get_object_or_404(Demande, id=id)

    if request.method == 'POST':

        form = DemandeForm(
            request.POST,
            instance=demande
        )

        if form.is_valid():

            form.save()

            messages.success(
                request,
                'Demande modifiée avec succès !'
            )

            return redirect('liste_demandes')

    else:

        form = DemandeForm(instance=demande)

    return render(
        request,
        'maintenance/demande_form.html',
        {
            'form': form,
            'titre_page': 'Modifier une demande'
        }
    )


# Supprimer une demande
def supprimer_demande(request, id):

    demande = get_object_or_404(Demande, id=id)

    if request.method == 'POST':

        demande.delete()

        messages.success(
            request,
            'Demande supprimée avec succès !'
        )

        return redirect('liste_demandes')

    return render(
        request,
        'maintenance/demande_confirm_delete.html',
        {'demande': demande}
    )


# Modifier le statut
def modifier_statut(request, id):

    demande = get_object_or_404(Demande, id=id)

    if request.method == 'POST':

        nouveau_statut = request.POST.get('statut')

        statuts_valides = dict(Demande.STATUT_CHOICES)

        if nouveau_statut in statuts_valides:

            demande.statut = nouveau_statut

            demande.save()

            messages.success(
                request,
                'Statut modifié avec succès !'
            )

        else:

            messages.error(
                request,
                'Statut invalide !'
            )

    return redirect('detail_demande', id=id)