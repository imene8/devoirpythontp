from django.contrib import admin
from .models import Categorie, Demande


@admin.register(Categorie)
class CategorieAdmin(admin.ModelAdmin):

    list_display = ('id', 'nom', 'description')

    search_fields = ('nom',)


@admin.register(Demande)
class DemandeAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'titre',
        'nom_demandeur',
        'email',
        'categorie',
        'date_creation',
        'statut'
    )

    list_filter = (
        'statut',
        'categorie',
        'date_creation'
    )

    search_fields = (
        'titre',
        'nom_demandeur',
        'email'
    )