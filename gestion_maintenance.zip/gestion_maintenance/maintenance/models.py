from django.db import models


class Categorie(models.Model):

    nom = models.CharField(max_length=100)

    description = models.TextField(
        blank=True,
        null=True
    )

    def __str__(self):
        return self.nom


class Demande(models.Model):

    STATUT_CHOICES = [
        ('En attente', 'En attente'),
        ('En cours de traitement', 'En cours de traitement'),
        ('Résolue', 'Résolue'),
    ]

    titre = models.CharField(max_length=200)

    description = models.TextField()

    nom_demandeur = models.CharField(max_length=100)

    email = models.EmailField()

    emplacement = models.CharField(max_length=150)

    categorie = models.ForeignKey(
        Categorie,
        on_delete=models.CASCADE,
        related_name='demandes'
    )

    date_creation = models.DateTimeField(
        auto_now_add=True
    )

    statut = models.CharField(
        max_length=30,
        choices=STATUT_CHOICES,
        default='En attente'
    )

    def __str__(self):
        return self.titre